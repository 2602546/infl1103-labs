from product import Product

class OrderLine:
    def __init__(self, product: Product, quantity: int) -> None:
        self.__product: Product = product
        self.__quantity: int = quantity

    def get_product(self) -> Product:
        return self.__product

    def get_quantity(self) -> int:
        return self.__quantity

    def calculate_subtotal(self) -> float:
        return self.__product.get_price() * self.__quantity

    def display_information(self) -> None:
        print("%s x %d @ $%.2f = $%.2f" % (self.__product.get_name(), self.__quantity, self.__product.get_price(), self.calculate_subtotal()))